package org.oristool.models.tpn;

import java.util.function.Supplier;
import javax.annotation.processing.Generated;
import org.oristool.analyzer.log.AnalysisLogger;
import org.oristool.analyzer.log.AnalysisMonitor;
import org.oristool.analyzer.policy.EnumerationPolicy;
import org.oristool.analyzer.stop.StopCriterion;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_TimedAnalysis extends TimedAnalysis {

  private final boolean includeAge;

  private final boolean markRegenerations;

  private final boolean excludeZeroProb;

  private final Supplier<EnumerationPolicy> policy;

  private final Supplier<StopCriterion> stopOn;

  private final AnalysisMonitor monitor;

  private final AnalysisLogger logger;

  private AutoValue_TimedAnalysis(
      boolean includeAge,
      boolean markRegenerations,
      boolean excludeZeroProb,
      Supplier<EnumerationPolicy> policy,
      Supplier<StopCriterion> stopOn,
      AnalysisMonitor monitor,
      AnalysisLogger logger) {
    this.includeAge = includeAge;
    this.markRegenerations = markRegenerations;
    this.excludeZeroProb = excludeZeroProb;
    this.policy = policy;
    this.stopOn = stopOn;
    this.monitor = monitor;
    this.logger = logger;
  }

  @Override
  public boolean includeAge() {
    return includeAge;
  }

  @Override
  public boolean markRegenerations() {
    return markRegenerations;
  }

  @Override
  public boolean excludeZeroProb() {
    return excludeZeroProb;
  }

  @Override
  public Supplier<EnumerationPolicy> policy() {
    return policy;
  }

  @Override
  public Supplier<StopCriterion> stopOn() {
    return stopOn;
  }

  @Override
  public AnalysisMonitor monitor() {
    return monitor;
  }

  @Override
  public AnalysisLogger logger() {
    return logger;
  }

  @Override
  public String toString() {
    return "TimedAnalysis{"
        + "includeAge=" + includeAge + ", "
        + "markRegenerations=" + markRegenerations + ", "
        + "excludeZeroProb=" + excludeZeroProb + ", "
        + "policy=" + policy + ", "
        + "stopOn=" + stopOn + ", "
        + "monitor=" + monitor + ", "
        + "logger=" + logger
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof TimedAnalysis) {
      TimedAnalysis that = (TimedAnalysis) o;
      return this.includeAge == that.includeAge()
          && this.markRegenerations == that.markRegenerations()
          && this.excludeZeroProb == that.excludeZeroProb()
          && this.policy.equals(that.policy())
          && this.stopOn.equals(that.stopOn())
          && this.monitor.equals(that.monitor())
          && this.logger.equals(that.logger());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= includeAge ? 1231 : 1237;
    h$ *= 1000003;
    h$ ^= markRegenerations ? 1231 : 1237;
    h$ *= 1000003;
    h$ ^= excludeZeroProb ? 1231 : 1237;
    h$ *= 1000003;
    h$ ^= policy.hashCode();
    h$ *= 1000003;
    h$ ^= stopOn.hashCode();
    h$ *= 1000003;
    h$ ^= monitor.hashCode();
    h$ *= 1000003;
    h$ ^= logger.hashCode();
    return h$;
  }

  static final class Builder extends TimedAnalysis.Builder {
    private boolean includeAge;
    private boolean markRegenerations;
    private boolean excludeZeroProb;
    private Supplier<EnumerationPolicy> policy;
    private Supplier<StopCriterion> stopOn;
    private AnalysisMonitor monitor;
    private AnalysisLogger logger;
    private byte set$0;
    Builder() {
    }
    @Override
    public TimedAnalysis.Builder includeAge(boolean includeAge) {
      this.includeAge = includeAge;
      set$0 |= (byte) 1;
      return this;
    }
    @Override
    public TimedAnalysis.Builder markRegenerations(boolean markRegenerations) {
      this.markRegenerations = markRegenerations;
      set$0 |= (byte) 2;
      return this;
    }
    @Override
    public TimedAnalysis.Builder excludeZeroProb(boolean excludeZeroProb) {
      this.excludeZeroProb = excludeZeroProb;
      set$0 |= (byte) 4;
      return this;
    }
    @Override
    public TimedAnalysis.Builder policy(Supplier<EnumerationPolicy> policy) {
      if (policy == null) {
        throw new NullPointerException("Null policy");
      }
      this.policy = policy;
      return this;
    }
    @Override
    public TimedAnalysis.Builder stopOn(Supplier<StopCriterion> stopOn) {
      if (stopOn == null) {
        throw new NullPointerException("Null stopOn");
      }
      this.stopOn = stopOn;
      return this;
    }
    @Override
    public TimedAnalysis.Builder monitor(AnalysisMonitor monitor) {
      if (monitor == null) {
        throw new NullPointerException("Null monitor");
      }
      this.monitor = monitor;
      return this;
    }
    @Override
    public TimedAnalysis.Builder logger(AnalysisLogger logger) {
      if (logger == null) {
        throw new NullPointerException("Null logger");
      }
      this.logger = logger;
      return this;
    }
    @Override
    public TimedAnalysis build() {
      if (set$0 != 7
          || this.policy == null
          || this.stopOn == null
          || this.monitor == null
          || this.logger == null) {
        StringBuilder missing = new StringBuilder();
        if ((set$0 & 1) == 0) {
          missing.append(" includeAge");
        }
        if ((set$0 & 2) == 0) {
          missing.append(" markRegenerations");
        }
        if ((set$0 & 4) == 0) {
          missing.append(" excludeZeroProb");
        }
        if (this.policy == null) {
          missing.append(" policy");
        }
        if (this.stopOn == null) {
          missing.append(" stopOn");
        }
        if (this.monitor == null) {
          missing.append(" monitor");
        }
        if (this.logger == null) {
          missing.append(" logger");
        }
        throw new IllegalStateException("Missing required properties:" + missing);
      }
      return new AutoValue_TimedAnalysis(
          this.includeAge,
          this.markRegenerations,
          this.excludeZeroProb,
          this.policy,
          this.stopOn,
          this.monitor,
          this.logger);
    }
  }

}
