package org.oristool.models.stpn.trans;

import java.math.BigDecimal;
import java.util.function.Supplier;
import javax.annotation.processing.Generated;
import org.oristool.analyzer.log.AnalysisLogger;
import org.oristool.analyzer.log.AnalysisMonitor;
import org.oristool.analyzer.policy.EnumerationPolicy;
import org.oristool.analyzer.stop.StopCriterion;
import org.oristool.petrinet.MarkingCondition;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_RegTransient extends RegTransient {

  private final BigDecimal timeBound;

  private final BigDecimal timeStep;

  private final Supplier<EnumerationPolicy> policy;

  private final int localEvaluationPeriod;

  private final int globalEvaluationPeriod;

  private final boolean normalizeKernels;

  private final Supplier<StopCriterion> stopOn;

  private final MarkingCondition markingFilter;

  private final AnalysisMonitor monitor;

  private final AnalysisLogger logger;

  private AutoValue_RegTransient(
      BigDecimal timeBound,
      BigDecimal timeStep,
      Supplier<EnumerationPolicy> policy,
      int localEvaluationPeriod,
      int globalEvaluationPeriod,
      boolean normalizeKernels,
      Supplier<StopCriterion> stopOn,
      MarkingCondition markingFilter,
      AnalysisMonitor monitor,
      AnalysisLogger logger) {
    this.timeBound = timeBound;
    this.timeStep = timeStep;
    this.policy = policy;
    this.localEvaluationPeriod = localEvaluationPeriod;
    this.globalEvaluationPeriod = globalEvaluationPeriod;
    this.normalizeKernels = normalizeKernels;
    this.stopOn = stopOn;
    this.markingFilter = markingFilter;
    this.monitor = monitor;
    this.logger = logger;
  }

  @Override
  public BigDecimal timeBound() {
    return timeBound;
  }

  @Override
  public BigDecimal timeStep() {
    return timeStep;
  }

  @Override
  public Supplier<EnumerationPolicy> policy() {
    return policy;
  }

  @Override
  public int localEvaluationPeriod() {
    return localEvaluationPeriod;
  }

  @Override
  public int globalEvaluationPeriod() {
    return globalEvaluationPeriod;
  }

  @Override
  public boolean normalizeKernels() {
    return normalizeKernels;
  }

  @Override
  public Supplier<StopCriterion> stopOn() {
    return stopOn;
  }

  @Override
  public MarkingCondition markingFilter() {
    return markingFilter;
  }

  @Override
  public AnalysisMonitor monitor() {
    return monitor;
  }

  @Override
  public AnalysisLogger logger() {
    return logger;
  }

  @Override
  public String toString() {
    return "RegTransient{"
        + "timeBound=" + timeBound + ", "
        + "timeStep=" + timeStep + ", "
        + "policy=" + policy + ", "
        + "localEvaluationPeriod=" + localEvaluationPeriod + ", "
        + "globalEvaluationPeriod=" + globalEvaluationPeriod + ", "
        + "normalizeKernels=" + normalizeKernels + ", "
        + "stopOn=" + stopOn + ", "
        + "markingFilter=" + markingFilter + ", "
        + "monitor=" + monitor + ", "
        + "logger=" + logger
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof RegTransient) {
      RegTransient that = (RegTransient) o;
      return this.timeBound.equals(that.timeBound())
          && this.timeStep.equals(that.timeStep())
          && this.policy.equals(that.policy())
          && this.localEvaluationPeriod == that.localEvaluationPeriod()
          && this.globalEvaluationPeriod == that.globalEvaluationPeriod()
          && this.normalizeKernels == that.normalizeKernels()
          && this.stopOn.equals(that.stopOn())
          && this.markingFilter.equals(that.markingFilter())
          && this.monitor.equals(that.monitor())
          && this.logger.equals(that.logger());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= timeBound.hashCode();
    h$ *= 1000003;
    h$ ^= timeStep.hashCode();
    h$ *= 1000003;
    h$ ^= policy.hashCode();
    h$ *= 1000003;
    h$ ^= localEvaluationPeriod;
    h$ *= 1000003;
    h$ ^= globalEvaluationPeriod;
    h$ *= 1000003;
    h$ ^= normalizeKernels ? 1231 : 1237;
    h$ *= 1000003;
    h$ ^= stopOn.hashCode();
    h$ *= 1000003;
    h$ ^= markingFilter.hashCode();
    h$ *= 1000003;
    h$ ^= monitor.hashCode();
    h$ *= 1000003;
    h$ ^= logger.hashCode();
    return h$;
  }

  static final class Builder extends RegTransient.Builder {
    private BigDecimal timeBound;
    private BigDecimal timeStep;
    private Supplier<EnumerationPolicy> policy;
    private int localEvaluationPeriod;
    private int globalEvaluationPeriod;
    private boolean normalizeKernels;
    private Supplier<StopCriterion> stopOn;
    private MarkingCondition markingFilter;
    private AnalysisMonitor monitor;
    private AnalysisLogger logger;
    private byte set$0;
    Builder() {
    }
    @Override
    public RegTransient.Builder timeBound(BigDecimal timeBound) {
      if (timeBound == null) {
        throw new NullPointerException("Null timeBound");
      }
      this.timeBound = timeBound;
      return this;
    }
    @Override
    public RegTransient.Builder timeStep(BigDecimal timeStep) {
      if (timeStep == null) {
        throw new NullPointerException("Null timeStep");
      }
      this.timeStep = timeStep;
      return this;
    }
    @Override
    public RegTransient.Builder policy(Supplier<EnumerationPolicy> policy) {
      if (policy == null) {
        throw new NullPointerException("Null policy");
      }
      this.policy = policy;
      return this;
    }
    @Override
    public RegTransient.Builder localEvaluationPeriod(int localEvaluationPeriod) {
      this.localEvaluationPeriod = localEvaluationPeriod;
      set$0 |= (byte) 1;
      return this;
    }
    @Override
    public RegTransient.Builder globalEvaluationPeriod(int globalEvaluationPeriod) {
      this.globalEvaluationPeriod = globalEvaluationPeriod;
      set$0 |= (byte) 2;
      return this;
    }
    @Override
    public RegTransient.Builder normalizeKernels(boolean normalizeKernels) {
      this.normalizeKernels = normalizeKernels;
      set$0 |= (byte) 4;
      return this;
    }
    @Override
    public RegTransient.Builder stopOn(Supplier<StopCriterion> stopOn) {
      if (stopOn == null) {
        throw new NullPointerException("Null stopOn");
      }
      this.stopOn = stopOn;
      return this;
    }
    @Override
    public RegTransient.Builder markingFilter(MarkingCondition markingFilter) {
      if (markingFilter == null) {
        throw new NullPointerException("Null markingFilter");
      }
      this.markingFilter = markingFilter;
      return this;
    }
    @Override
    public RegTransient.Builder monitor(AnalysisMonitor monitor) {
      if (monitor == null) {
        throw new NullPointerException("Null monitor");
      }
      this.monitor = monitor;
      return this;
    }
    @Override
    public RegTransient.Builder logger(AnalysisLogger logger) {
      if (logger == null) {
        throw new NullPointerException("Null logger");
      }
      this.logger = logger;
      return this;
    }
    @Override
    public RegTransient build() {
      if (set$0 != 7
          || this.timeBound == null
          || this.timeStep == null
          || this.policy == null
          || this.stopOn == null
          || this.markingFilter == null
          || this.monitor == null
          || this.logger == null) {
        StringBuilder missing = new StringBuilder();
        if (this.timeBound == null) {
          missing.append(" timeBound");
        }
        if (this.timeStep == null) {
          missing.append(" timeStep");
        }
        if (this.policy == null) {
          missing.append(" policy");
        }
        if ((set$0 & 1) == 0) {
          missing.append(" localEvaluationPeriod");
        }
        if ((set$0 & 2) == 0) {
          missing.append(" globalEvaluationPeriod");
        }
        if ((set$0 & 4) == 0) {
          missing.append(" normalizeKernels");
        }
        if (this.stopOn == null) {
          missing.append(" stopOn");
        }
        if (this.markingFilter == null) {
          missing.append(" markingFilter");
        }
        if (this.monitor == null) {
          missing.append(" monitor");
        }
        if (this.logger == null) {
          missing.append(" logger");
        }
        throw new IllegalStateException("Missing required properties:" + missing);
      }
      return new AutoValue_RegTransient(
          this.timeBound,
          this.timeStep,
          this.policy,
          this.localEvaluationPeriod,
          this.globalEvaluationPeriod,
          this.normalizeKernels,
          this.stopOn,
          this.markingFilter,
          this.monitor,
          this.logger);
    }
  }

}
