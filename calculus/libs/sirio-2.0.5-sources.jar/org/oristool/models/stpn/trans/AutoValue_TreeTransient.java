package org.oristool.models.stpn.trans;

import java.math.BigDecimal;
import java.util.function.Supplier;
import javax.annotation.processing.Generated;
import org.oristool.analyzer.log.AnalysisLogger;
import org.oristool.analyzer.log.AnalysisMonitor;
import org.oristool.analyzer.policy.EnumerationPolicy;
import org.oristool.analyzer.stop.StopCriterion;
import org.oristool.petrinet.MarkingCondition;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_TreeTransient extends TreeTransient {

  private final BigDecimal timeBound;

  private final BigDecimal timeStep;

  private final Supplier<EnumerationPolicy> policy;

  private final Supplier<StopCriterion> stopOn;

  private final MarkingCondition markingFilter;

  private final boolean evaluateByClass;

  private final AnalysisMonitor monitor;

  private final AnalysisLogger logger;

  private AutoValue_TreeTransient(
      BigDecimal timeBound,
      BigDecimal timeStep,
      Supplier<EnumerationPolicy> policy,
      Supplier<StopCriterion> stopOn,
      MarkingCondition markingFilter,
      boolean evaluateByClass,
      AnalysisMonitor monitor,
      AnalysisLogger logger) {
    this.timeBound = timeBound;
    this.timeStep = timeStep;
    this.policy = policy;
    this.stopOn = stopOn;
    this.markingFilter = markingFilter;
    this.evaluateByClass = evaluateByClass;
    this.monitor = monitor;
    this.logger = logger;
  }

  @Override
  public BigDecimal timeBound() {
    return timeBound;
  }

  @Override
  public BigDecimal timeStep() {
    return timeStep;
  }

  @Override
  public Supplier<EnumerationPolicy> policy() {
    return policy;
  }

  @Override
  public Supplier<StopCriterion> stopOn() {
    return stopOn;
  }

  @Override
  public MarkingCondition markingFilter() {
    return markingFilter;
  }

  @Override
  public boolean evaluateByClass() {
    return evaluateByClass;
  }

  @Override
  public AnalysisMonitor monitor() {
    return monitor;
  }

  @Override
  public AnalysisLogger logger() {
    return logger;
  }

  @Override
  public String toString() {
    return "TreeTransient{"
        + "timeBound=" + timeBound + ", "
        + "timeStep=" + timeStep + ", "
        + "policy=" + policy + ", "
        + "stopOn=" + stopOn + ", "
        + "markingFilter=" + markingFilter + ", "
        + "evaluateByClass=" + evaluateByClass + ", "
        + "monitor=" + monitor + ", "
        + "logger=" + logger
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof TreeTransient) {
      TreeTransient that = (TreeTransient) o;
      return this.timeBound.equals(that.timeBound())
          && this.timeStep.equals(that.timeStep())
          && this.policy.equals(that.policy())
          && this.stopOn.equals(that.stopOn())
          && this.markingFilter.equals(that.markingFilter())
          && this.evaluateByClass == that.evaluateByClass()
          && this.monitor.equals(that.monitor())
          && this.logger.equals(that.logger());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= timeBound.hashCode();
    h$ *= 1000003;
    h$ ^= timeStep.hashCode();
    h$ *= 1000003;
    h$ ^= policy.hashCode();
    h$ *= 1000003;
    h$ ^= stopOn.hashCode();
    h$ *= 1000003;
    h$ ^= markingFilter.hashCode();
    h$ *= 1000003;
    h$ ^= evaluateByClass ? 1231 : 1237;
    h$ *= 1000003;
    h$ ^= monitor.hashCode();
    h$ *= 1000003;
    h$ ^= logger.hashCode();
    return h$;
  }

  static final class Builder extends TreeTransient.Builder {
    private BigDecimal timeBound;
    private BigDecimal timeStep;
    private Supplier<EnumerationPolicy> policy;
    private Supplier<StopCriterion> stopOn;
    private MarkingCondition markingFilter;
    private boolean evaluateByClass;
    private AnalysisMonitor monitor;
    private AnalysisLogger logger;
    private byte set$0;
    Builder() {
    }
    @Override
    public TreeTransient.Builder timeBound(BigDecimal timeBound) {
      if (timeBound == null) {
        throw new NullPointerException("Null timeBound");
      }
      this.timeBound = timeBound;
      return this;
    }
    @Override
    public TreeTransient.Builder timeStep(BigDecimal timeStep) {
      if (timeStep == null) {
        throw new NullPointerException("Null timeStep");
      }
      this.timeStep = timeStep;
      return this;
    }
    @Override
    public TreeTransient.Builder policy(Supplier<EnumerationPolicy> policy) {
      if (policy == null) {
        throw new NullPointerException("Null policy");
      }
      this.policy = policy;
      return this;
    }
    @Override
    public TreeTransient.Builder stopOn(Supplier<StopCriterion> stopOn) {
      if (stopOn == null) {
        throw new NullPointerException("Null stopOn");
      }
      this.stopOn = stopOn;
      return this;
    }
    @Override
    public TreeTransient.Builder markingFilter(MarkingCondition markingFilter) {
      if (markingFilter == null) {
        throw new NullPointerException("Null markingFilter");
      }
      this.markingFilter = markingFilter;
      return this;
    }
    @Override
    public TreeTransient.Builder evaluateByClass(boolean evaluateByClass) {
      this.evaluateByClass = evaluateByClass;
      set$0 |= (byte) 1;
      return this;
    }
    @Override
    public TreeTransient.Builder monitor(AnalysisMonitor monitor) {
      if (monitor == null) {
        throw new NullPointerException("Null monitor");
      }
      this.monitor = monitor;
      return this;
    }
    @Override
    public TreeTransient.Builder logger(AnalysisLogger logger) {
      if (logger == null) {
        throw new NullPointerException("Null logger");
      }
      this.logger = logger;
      return this;
    }
    @Override
    public TreeTransient build() {
      if (set$0 != 1
          || this.timeBound == null
          || this.timeStep == null
          || this.policy == null
          || this.stopOn == null
          || this.markingFilter == null
          || this.monitor == null
          || this.logger == null) {
        StringBuilder missing = new StringBuilder();
        if (this.timeBound == null) {
          missing.append(" timeBound");
        }
        if (this.timeStep == null) {
          missing.append(" timeStep");
        }
        if (this.policy == null) {
          missing.append(" policy");
        }
        if (this.stopOn == null) {
          missing.append(" stopOn");
        }
        if (this.markingFilter == null) {
          missing.append(" markingFilter");
        }
        if ((set$0 & 1) == 0) {
          missing.append(" evaluateByClass");
        }
        if (this.monitor == null) {
          missing.append(" monitor");
        }
        if (this.logger == null) {
          missing.append(" logger");
        }
        throw new IllegalStateException("Missing required properties:" + missing);
      }
      return new AutoValue_TreeTransient(
          this.timeBound,
          this.timeStep,
          this.policy,
          this.stopOn,
          this.markingFilter,
          this.evaluateByClass,
          this.monitor,
          this.logger);
    }
  }

}
