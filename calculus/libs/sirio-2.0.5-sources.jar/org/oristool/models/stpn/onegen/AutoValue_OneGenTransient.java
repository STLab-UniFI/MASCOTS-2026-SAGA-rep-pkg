package org.oristool.models.stpn.onegen;

import java.math.BigDecimal;
import java.util.function.Supplier;
import javax.annotation.processing.Generated;
import org.oristool.analyzer.log.AnalysisLogger;
import org.oristool.analyzer.log.AnalysisMonitor;
import org.oristool.analyzer.stop.StopCriterion;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_OneGenTransient extends OneGenTransient {

  private final BigDecimal timeBound;

  private final BigDecimal timeStep;

  private final BigDecimal error;

  private final Supplier<StopCriterion> stopOn;

  private final AnalysisMonitor monitor;

  private final AnalysisLogger logger;

  private AutoValue_OneGenTransient(
      BigDecimal timeBound,
      BigDecimal timeStep,
      BigDecimal error,
      Supplier<StopCriterion> stopOn,
      AnalysisMonitor monitor,
      AnalysisLogger logger) {
    this.timeBound = timeBound;
    this.timeStep = timeStep;
    this.error = error;
    this.stopOn = stopOn;
    this.monitor = monitor;
    this.logger = logger;
  }

  @Override
  public BigDecimal timeBound() {
    return timeBound;
  }

  @Override
  public BigDecimal timeStep() {
    return timeStep;
  }

  @Override
  public BigDecimal error() {
    return error;
  }

  @Override
  public Supplier<StopCriterion> stopOn() {
    return stopOn;
  }

  @Override
  public AnalysisMonitor monitor() {
    return monitor;
  }

  @Override
  public AnalysisLogger logger() {
    return logger;
  }

  @Override
  public String toString() {
    return "OneGenTransient{"
        + "timeBound=" + timeBound + ", "
        + "timeStep=" + timeStep + ", "
        + "error=" + error + ", "
        + "stopOn=" + stopOn + ", "
        + "monitor=" + monitor + ", "
        + "logger=" + logger
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof OneGenTransient) {
      OneGenTransient that = (OneGenTransient) o;
      return this.timeBound.equals(that.timeBound())
          && this.timeStep.equals(that.timeStep())
          && this.error.equals(that.error())
          && this.stopOn.equals(that.stopOn())
          && this.monitor.equals(that.monitor())
          && this.logger.equals(that.logger());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= timeBound.hashCode();
    h$ *= 1000003;
    h$ ^= timeStep.hashCode();
    h$ *= 1000003;
    h$ ^= error.hashCode();
    h$ *= 1000003;
    h$ ^= stopOn.hashCode();
    h$ *= 1000003;
    h$ ^= monitor.hashCode();
    h$ *= 1000003;
    h$ ^= logger.hashCode();
    return h$;
  }

  static final class Builder extends OneGenTransient.Builder {
    private BigDecimal timeBound;
    private BigDecimal timeStep;
    private BigDecimal error;
    private Supplier<StopCriterion> stopOn;
    private AnalysisMonitor monitor;
    private AnalysisLogger logger;
    Builder() {
    }
    @Override
    public OneGenTransient.Builder timeBound(BigDecimal timeBound) {
      if (timeBound == null) {
        throw new NullPointerException("Null timeBound");
      }
      this.timeBound = timeBound;
      return this;
    }
    @Override
    public OneGenTransient.Builder timeStep(BigDecimal timeStep) {
      if (timeStep == null) {
        throw new NullPointerException("Null timeStep");
      }
      this.timeStep = timeStep;
      return this;
    }
    @Override
    public OneGenTransient.Builder error(BigDecimal error) {
      if (error == null) {
        throw new NullPointerException("Null error");
      }
      this.error = error;
      return this;
    }
    @Override
    public OneGenTransient.Builder stopOn(Supplier<StopCriterion> stopOn) {
      if (stopOn == null) {
        throw new NullPointerException("Null stopOn");
      }
      this.stopOn = stopOn;
      return this;
    }
    @Override
    public OneGenTransient.Builder monitor(AnalysisMonitor monitor) {
      if (monitor == null) {
        throw new NullPointerException("Null monitor");
      }
      this.monitor = monitor;
      return this;
    }
    @Override
    public OneGenTransient.Builder logger(AnalysisLogger logger) {
      if (logger == null) {
        throw new NullPointerException("Null logger");
      }
      this.logger = logger;
      return this;
    }
    @Override
    public OneGenTransient build() {
      if (this.timeBound == null
          || this.timeStep == null
          || this.error == null
          || this.stopOn == null
          || this.monitor == null
          || this.logger == null) {
        StringBuilder missing = new StringBuilder();
        if (this.timeBound == null) {
          missing.append(" timeBound");
        }
        if (this.timeStep == null) {
          missing.append(" timeStep");
        }
        if (this.error == null) {
          missing.append(" error");
        }
        if (this.stopOn == null) {
          missing.append(" stopOn");
        }
        if (this.monitor == null) {
          missing.append(" monitor");
        }
        if (this.logger == null) {
          missing.append(" logger");
        }
        throw new IllegalStateException("Missing required properties:" + missing);
      }
      return new AutoValue_OneGenTransient(
          this.timeBound,
          this.timeStep,
          this.error,
          this.stopOn,
          this.monitor,
          this.logger);
    }
  }

}
