package org.oristool.models.gspn;

import java.util.function.Supplier;
import javax.annotation.processing.Generated;
import org.oristool.analyzer.log.AnalysisLogger;
import org.oristool.analyzer.log.AnalysisMonitor;
import org.oristool.analyzer.stop.StopCriterion;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_GSPNSteadyState extends GSPNSteadyState {

  private final double epsilon;

  private final Supplier<StopCriterion> stopOn;

  private final AnalysisMonitor monitor;

  private final AnalysisLogger logger;

  private AutoValue_GSPNSteadyState(
      double epsilon,
      Supplier<StopCriterion> stopOn,
      AnalysisMonitor monitor,
      AnalysisLogger logger) {
    this.epsilon = epsilon;
    this.stopOn = stopOn;
    this.monitor = monitor;
    this.logger = logger;
  }

  @Override
  public double epsilon() {
    return epsilon;
  }

  @Override
  public Supplier<StopCriterion> stopOn() {
    return stopOn;
  }

  @Override
  public AnalysisMonitor monitor() {
    return monitor;
  }

  @Override
  public AnalysisLogger logger() {
    return logger;
  }

  @Override
  public String toString() {
    return "GSPNSteadyState{"
        + "epsilon=" + epsilon + ", "
        + "stopOn=" + stopOn + ", "
        + "monitor=" + monitor + ", "
        + "logger=" + logger
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof GSPNSteadyState) {
      GSPNSteadyState that = (GSPNSteadyState) o;
      return Double.doubleToLongBits(this.epsilon) == Double.doubleToLongBits(that.epsilon())
          && this.stopOn.equals(that.stopOn())
          && this.monitor.equals(that.monitor())
          && this.logger.equals(that.logger());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= (int) ((Double.doubleToLongBits(epsilon) >>> 32) ^ Double.doubleToLongBits(epsilon));
    h$ *= 1000003;
    h$ ^= stopOn.hashCode();
    h$ *= 1000003;
    h$ ^= monitor.hashCode();
    h$ *= 1000003;
    h$ ^= logger.hashCode();
    return h$;
  }

  static final class Builder extends GSPNSteadyState.Builder {
    private double epsilon;
    private Supplier<StopCriterion> stopOn;
    private AnalysisMonitor monitor;
    private AnalysisLogger logger;
    private byte set$0;
    Builder() {
    }
    @Override
    public GSPNSteadyState.Builder epsilon(double epsilon) {
      this.epsilon = epsilon;
      set$0 |= (byte) 1;
      return this;
    }
    @Override
    public GSPNSteadyState.Builder stopOn(Supplier<StopCriterion> stopOn) {
      if (stopOn == null) {
        throw new NullPointerException("Null stopOn");
      }
      this.stopOn = stopOn;
      return this;
    }
    @Override
    public GSPNSteadyState.Builder monitor(AnalysisMonitor monitor) {
      if (monitor == null) {
        throw new NullPointerException("Null monitor");
      }
      this.monitor = monitor;
      return this;
    }
    @Override
    public GSPNSteadyState.Builder logger(AnalysisLogger logger) {
      if (logger == null) {
        throw new NullPointerException("Null logger");
      }
      this.logger = logger;
      return this;
    }
    @Override
    public GSPNSteadyState build() {
      if (set$0 != 1
          || this.stopOn == null
          || this.monitor == null
          || this.logger == null) {
        StringBuilder missing = new StringBuilder();
        if ((set$0 & 1) == 0) {
          missing.append(" epsilon");
        }
        if (this.stopOn == null) {
          missing.append(" stopOn");
        }
        if (this.monitor == null) {
          missing.append(" monitor");
        }
        if (this.logger == null) {
          missing.append(" logger");
        }
        throw new IllegalStateException("Missing required properties:" + missing);
      }
      return new AutoValue_GSPNSteadyState(
          this.epsilon,
          this.stopOn,
          this.monitor,
          this.logger);
    }
  }

}
