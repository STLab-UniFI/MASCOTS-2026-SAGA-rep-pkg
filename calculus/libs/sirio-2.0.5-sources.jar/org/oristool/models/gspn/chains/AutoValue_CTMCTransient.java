package org.oristool.models.gspn.chains;

import javax.annotation.processing.Generated;
import org.oristool.analyzer.log.AnalysisLogger;
import org.oristool.analyzer.log.AnalysisMonitor;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_CTMCTransient<M, S extends CTMCState<M>> extends CTMCTransient<M, S> {

  private final double error;

  private final double epsilon;

  private final AnalysisMonitor monitor;

  private final AnalysisLogger logger;

  private AutoValue_CTMCTransient(
      double error,
      double epsilon,
      AnalysisMonitor monitor,
      AnalysisLogger logger) {
    this.error = error;
    this.epsilon = epsilon;
    this.monitor = monitor;
    this.logger = logger;
  }

  @Override
  public double error() {
    return error;
  }

  @Override
  public double epsilon() {
    return epsilon;
  }

  @Override
  public AnalysisMonitor monitor() {
    return monitor;
  }

  @Override
  public AnalysisLogger logger() {
    return logger;
  }

  @Override
  public String toString() {
    return "CTMCTransient{"
        + "error=" + error + ", "
        + "epsilon=" + epsilon + ", "
        + "monitor=" + monitor + ", "
        + "logger=" + logger
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof CTMCTransient) {
      CTMCTransient<?, ?> that = (CTMCTransient<?, ?>) o;
      return Double.doubleToLongBits(this.error) == Double.doubleToLongBits(that.error())
          && Double.doubleToLongBits(this.epsilon) == Double.doubleToLongBits(that.epsilon())
          && this.monitor.equals(that.monitor())
          && this.logger.equals(that.logger());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= (int) ((Double.doubleToLongBits(error) >>> 32) ^ Double.doubleToLongBits(error));
    h$ *= 1000003;
    h$ ^= (int) ((Double.doubleToLongBits(epsilon) >>> 32) ^ Double.doubleToLongBits(epsilon));
    h$ *= 1000003;
    h$ ^= monitor.hashCode();
    h$ *= 1000003;
    h$ ^= logger.hashCode();
    return h$;
  }

  static final class Builder<M, S extends CTMCState<M>> extends CTMCTransient.Builder<M, S> {
    private double error;
    private double epsilon;
    private AnalysisMonitor monitor;
    private AnalysisLogger logger;
    private byte set$0;
    Builder() {
    }
    @Override
    public CTMCTransient.Builder<M, S> error(double error) {
      this.error = error;
      set$0 |= (byte) 1;
      return this;
    }
    @Override
    public CTMCTransient.Builder<M, S> epsilon(double epsilon) {
      this.epsilon = epsilon;
      set$0 |= (byte) 2;
      return this;
    }
    @Override
    public CTMCTransient.Builder<M, S> monitor(AnalysisMonitor monitor) {
      if (monitor == null) {
        throw new NullPointerException("Null monitor");
      }
      this.monitor = monitor;
      return this;
    }
    @Override
    public CTMCTransient.Builder<M, S> logger(AnalysisLogger logger) {
      if (logger == null) {
        throw new NullPointerException("Null logger");
      }
      this.logger = logger;
      return this;
    }
    @Override
    public CTMCTransient<M, S> build() {
      if (set$0 != 3
          || this.monitor == null
          || this.logger == null) {
        StringBuilder missing = new StringBuilder();
        if ((set$0 & 1) == 0) {
          missing.append(" error");
        }
        if ((set$0 & 2) == 0) {
          missing.append(" epsilon");
        }
        if (this.monitor == null) {
          missing.append(" monitor");
        }
        if (this.logger == null) {
          missing.append(" logger");
        }
        throw new IllegalStateException("Missing required properties:" + missing);
      }
      return new AutoValue_CTMCTransient<M, S>(
          this.error,
          this.epsilon,
          this.monitor,
          this.logger);
    }
  }

}
