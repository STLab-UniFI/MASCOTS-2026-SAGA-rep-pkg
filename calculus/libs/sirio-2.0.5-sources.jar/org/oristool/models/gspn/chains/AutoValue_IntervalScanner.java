package org.oristool.models.gspn.chains;

import java.util.List;
import javax.annotation.processing.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_IntervalScanner<E extends Interval> extends IntervalScanner<E> {

  private final List<E> intervals;

  private AutoValue_IntervalScanner(
      List<E> intervals) {
    this.intervals = intervals;
  }

  @Override
  public List<E> intervals() {
    return intervals;
  }

  @Override
  public String toString() {
    return "IntervalScanner{"
        + "intervals=" + intervals
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof IntervalScanner) {
      IntervalScanner<?> that = (IntervalScanner<?>) o;
      return this.intervals.equals(that.intervals());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= intervals.hashCode();
    return h$;
  }

  static final class Builder<E extends Interval> extends IntervalScanner.Builder<E> {
    private LinkedListBuilder<E> intervalsBuilder$;
    private List<E> intervals;
    Builder() {
    }
    @Override
    LinkedListBuilder<E> intervalsBuilder() {
      if (intervalsBuilder$ == null) {
        intervalsBuilder$ = new LinkedListBuilder<E>();
      }
      return intervalsBuilder$;
    }
    @Override
    IntervalScanner<E> autoBuild() {
      if (intervalsBuilder$ != null) {
        this.intervals = intervalsBuilder$.build();
      } else if (this.intervals == null) {
        this.intervals = List.of();
      }
      return new AutoValue_IntervalScanner<E>(
          this.intervals);
    }
  }

}
