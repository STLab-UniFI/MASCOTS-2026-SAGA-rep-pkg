package org.oristool.models.gspn.chains;

import javax.annotation.processing.Generated;
import org.oristool.analyzer.log.AnalysisLogger;
import org.oristool.analyzer.log.AnalysisMonitor;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_CTMCStationary<M, S extends CTMCState<M>> extends CTMCStationary<M, S> {

  private final double epsilon;

  private final AnalysisMonitor monitor;

  private final AnalysisLogger logger;

  private AutoValue_CTMCStationary(
      double epsilon,
      AnalysisMonitor monitor,
      AnalysisLogger logger) {
    this.epsilon = epsilon;
    this.monitor = monitor;
    this.logger = logger;
  }

  @Override
  public double epsilon() {
    return epsilon;
  }

  @Override
  public AnalysisMonitor monitor() {
    return monitor;
  }

  @Override
  public AnalysisLogger logger() {
    return logger;
  }

  @Override
  public String toString() {
    return "CTMCStationary{"
        + "epsilon=" + epsilon + ", "
        + "monitor=" + monitor + ", "
        + "logger=" + logger
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof CTMCStationary) {
      CTMCStationary<?, ?> that = (CTMCStationary<?, ?>) o;
      return Double.doubleToLongBits(this.epsilon) == Double.doubleToLongBits(that.epsilon())
          && this.monitor.equals(that.monitor())
          && this.logger.equals(that.logger());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= (int) ((Double.doubleToLongBits(epsilon) >>> 32) ^ Double.doubleToLongBits(epsilon));
    h$ *= 1000003;
    h$ ^= monitor.hashCode();
    h$ *= 1000003;
    h$ ^= logger.hashCode();
    return h$;
  }

  static final class Builder<M, S extends CTMCState<M>> extends CTMCStationary.Builder<M, S> {
    private double epsilon;
    private AnalysisMonitor monitor;
    private AnalysisLogger logger;
    private byte set$0;
    Builder() {
    }
    @Override
    public CTMCStationary.Builder<M, S> epsilon(double epsilon) {
      this.epsilon = epsilon;
      set$0 |= (byte) 1;
      return this;
    }
    @Override
    public CTMCStationary.Builder<M, S> monitor(AnalysisMonitor monitor) {
      if (monitor == null) {
        throw new NullPointerException("Null monitor");
      }
      this.monitor = monitor;
      return this;
    }
    @Override
    public CTMCStationary.Builder<M, S> logger(AnalysisLogger logger) {
      if (logger == null) {
        throw new NullPointerException("Null logger");
      }
      this.logger = logger;
      return this;
    }
    @Override
    public CTMCStationary<M, S> build() {
      if (set$0 != 1
          || this.monitor == null
          || this.logger == null) {
        StringBuilder missing = new StringBuilder();
        if ((set$0 & 1) == 0) {
          missing.append(" epsilon");
        }
        if (this.monitor == null) {
          missing.append(" monitor");
        }
        if (this.logger == null) {
          missing.append(" logger");
        }
        throw new IllegalStateException("Missing required properties:" + missing);
      }
      return new AutoValue_CTMCStationary<M, S>(
          this.epsilon,
          this.monitor,
          this.logger);
    }
  }

}
